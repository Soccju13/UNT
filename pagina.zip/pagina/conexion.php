<?php
 $conexion = mysqli_connect("localhost","root","","bd_agencia");
    //if(!$conexion){   echo'Problema en la supuesta conexion';  }  else{ echo'Conecto, supuestamente!';    }
?>



