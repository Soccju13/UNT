<?php
include'conexion.php';
   // if(isset($_POST['btn-enviar'])) {
        $usuario = $_POST['usuario'];
        $dni = $_POST['dni'];
        $email = $_POST['email'];
        $destino = $_POST['destino'];

        $insertar = "INSERT INTO reserva(usuario, dni, email, destino) VALUES('$usuario','$dni','$email','$destino')";
        $ejecutar = mysqli_query($conexion,$insertar);
        //$ejecutar = $conexion->query($consulta);
        
        if(!$ejecutar){
            echo 'hubo un error al reservar el viaje, verifique los datos  ';
            echo "<input type='button' value='Volver al menu anterior' onClick='history.go(-1);'>";
        }
        else{
            echo'Reservo correctamente su viaje  ';
            echo "<input type='button' value='Volver al menu anterior' onClick='history.go(-1);'>";
        }
    mysqli_close($conexion);
    //}
?>