<?php
include'conexion.php';
   // if(isset($_POST['btn-enviar'])) {
        $nombre = $_POST['nombre'];
        $apellido = $_POST['apellido'];
        $email = $_POST['email'];
        $pregunta = $_POST['pregunta'];

        $insertar = "INSERT INTO contactanos(nombre, apellido, email, pregunta) VALUES('$nombre','$apellido','$email','$pregunta')";
        $ejecutar = mysqli_query($conexion,$insertar);
        //$ejecutar = $conexion->query($consulta);
        
        if(!$ejecutar){
            echo 'hubo un error al ejecutar sentencia  ';
            echo "<input type='button' value='Volver al menu anterior' onClick='history.go(-1);'>";
        }
        else{
            echo'Registro ingresado  ';
            echo "<input type='button' value='Volver al menu anterior' onClick='history.go(-1);'>";
        }
    mysqli_close($conexion);
    //}
?>