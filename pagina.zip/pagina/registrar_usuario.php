<?php
include'conexion.php';
   // if(isset($_POST['btn-enviar'])) {
        $usuario = $_POST['usuario'];
        $password = $_POST['password'];
        $email = $_POST['email'];
        $email_alternativo = $_POST['email_alternativo'];

        $insertar = "INSERT INTO login(usuario, password, email, email_alternativo) VALUES('$usuario','$password','$email','$email_alternativo')";
        $ejecutar = mysqli_query($conexion,$insertar);
        //$ejecutar = $conexion->query($consulta);
        if(!$ejecutar){
            echo 'hubo un error al ejecutar sentencia  ';
            echo "<input type='button' value='Volver al menu anterior' onClick='history.go(-1);'>";
        }
        else{
            echo'Registro ingresado  ';
            echo "<input type='button' value='Volver al menu anterior' onClick='history.go(-1);'>";
        }
    mysqli_close($conexion);
    //}
?>