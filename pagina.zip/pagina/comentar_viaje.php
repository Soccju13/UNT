<?php
include'conexion.php';
   // if(isset($_POST['btn-enviar'])) {
        $usuario = $_POST['usuario'];
        $password = $_POST['password'];
        $lugar_destino = $_POST['lugar_destino'];
        $comentario = $_POST['comentario'];

        $insertar = "INSERT INTO comentario(usuario, password, lugar_destino, comentario) VALUES('$usuario','$password','$lugar_destino','$comentario')";
        $ejecutar = mysqli_query($conexion,$insertar);
        //$ejecutar = $conexion->query($consulta);
        if(!$ejecutar){
            echo 'hubo un error al ejecutar sentencia ';
            echo "<input type='button' value='Volver al menu anterior' onClick='history.go(-1);'>";
        }
        else{
            echo'Registro ingresado ';
            echo "<input type='button' value='Volver al menu anterior' onClick='history.go(-1);'>";
        }
    mysqli_close($conexion);
    //}
?>