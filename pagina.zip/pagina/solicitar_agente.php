<?php
include'conexion.php';
   // if(isset($_POST['btn-enviar'])) {
        $usuario = $_POST['usuario'];
        $dni = $_POST['dni'];
        $email = $_POST['email'];
        $agente = $_POST['agente'];

        $insertar = "INSERT INTO solicitudes_agentes(usuario, dni, email, agente) VALUES('$usuario','$dni','$email','$agente')";
        $ejecutar = mysqli_query($conexion,$insertar);
        //$ejecutar = $conexion->query($consulta);
        
        if(!$ejecutar){
            echo 'hubo un error al reservar el viaje, verifique los datos  ';
            echo "<input type='button' value='Volver al menu anterior' onClick='history.go(-1);'>";
        }
        else{
            echo'Reservo correctamente su viaje  ';
            echo "<input type='button' value='Volver al menu anterior' onClick='history.go(-1);'>";
        }
    mysqli_close($conexion);
    //}
?>