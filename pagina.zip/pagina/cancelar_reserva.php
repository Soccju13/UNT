<?php
include'conexion.php';
   // if(isset($_POST['btn-enviar'])) {
        $usuario = $_POST['usuario'];

        $insertar = "DELETE FROM reserva WHERE usuario = '$usuario'";
        $ejecutar = mysqli_query($conexion,$insertar);
        //$ejecutar = $conexion->query($consulta);
        
        if(!$ejecutar){
            echo 'hubo un error al cancelar la reserva del viaje  ';
            echo "<input type='button' value='Volver al menu anterior' onClick='history.go(-1);'>";
        }
        else{
            echo'Reserva cancelada  ';
            echo "<input type='button' value='Volver al menu anterior' onClick='history.go(-1);'>";
        }
    mysqli_close($conexion);
    //}
?>